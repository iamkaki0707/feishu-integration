"""
Approval Service - Handles Feishu approval workflow operations
"""
import json
from typing import Dict, Any, Optional, List
from app.core.client import feishu_client
from app.services.token_service import token_service


class ApprovalService:
    """Service for handling Feishu approval workflows"""

    async def create_approval_instance(
        self,
        approval_code: str,
        form_data: List[Dict[str, Any]],
        user_id: str = None,
        user_id_type: str = "open_id"
    ) -> Dict[str, Any]:
        """
        Create a new approval instance

        Args:
            approval_code: Approval definition code (from Feishu admin console)
            form_data: Form data as list of {name: field_name, value: field_value}
            user_id: User ID who initiates the approval (optional)
            user_id_type: Type of user ID

        Returns:
            API response with instance ID
        """
        token = await token_service.get_tenant_access_token()

        # Build form data
        form = []
        for field in form_data:
            form.append({
                "name": field.get("name", ""),
                "value": field.get("value", "")
            })

        return await feishu_client.create_approval_instance(
            approval_code=approval_code,
            form_data=form,
            tenant_access_token=token
        )

    async def get_approval_instance_status(
        self,
        instance_id: str
    ) -> Dict[str, Any]:
        """
        Get approval instance status

        Args:
            instance_id: Approval instance ID

        Returns:
            Instance status and details
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.get_approval_instance(
            instance_id=instance_id,
            tenant_access_token=token
        )

    async def get_approval_definitions(self) -> Dict[str, Any]:
        """
        Get list of approval definitions

        Returns:
            List of approval definitions
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.get_approval_definitions(
            tenant_access_token=token
        )

    async def approve_request(
        self,
        instance_id: str,
        comment: str = ""
    ) -> Dict[str, Any]:
        """
        Approve an approval request

        Args:
            instance_id: Approval instance ID
            comment: Approval comment

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.approve_instance(
            instance_id=instance_id,
            comment=comment,
            tenant_access_token=token
        )

    async def reject_request(
        self,
        instance_id: str,
        comment: str = ""
    ) -> Dict[str, Any]:
        """
        Reject an approval request

        Args:
            instance_id: Approval instance ID
            comment: Rejection comment

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.reject_instance(
            instance_id=instance_id,
            comment=comment,
            tenant_access_token=token
        )

    # Helper methods for common approval types

    async def create_leave_approval(
        self,
        user_id: str,
        leave_type: str,
        start_date: str,
        end_date: str,
        reason: str = ""
    ) -> Dict[str, Any]:
        """
        Create a leave approval request

        Args:
            user_id: User ID
            leave_type: Leave type (年假, 病假, 事假, etc.)
            start_date: Start date
            end_date: End date
            reason: Reason for leave

        Returns:
            API response
        """
        # This is an example - actual approval_code depends on your Feishu approval definition
        approval_code = "leave_approval"  # Replace with actual approval code

        form_data = [
            {"name": "leave_type", "value": leave_type},
            {"name": "start_date", "value": start_date},
            {"name": "end_date", "value": end_date},
            {"name": "reason", "value": reason}
        ]

        return await self.create_approval_instance(
            approval_code=approval_code,
            form_data=form_data,
            user_id=user_id
        )

    async def create_reimbursement_approval(
        self,
        user_id: str,
        amount: float,
        expense_type: str,
        description: str
    ) -> Dict[str, Any]:
        """
        Create a reimbursement approval request

        Args:
            user_id: User ID
            amount: Reimbursement amount
            expense_type: Expense type (交通, 餐饮, 住宿, etc.)
            description: Description

        Returns:
            API response
        """
        # This is an example - actual approval_code depends on your Feishu approval definition
        approval_code = "reimbursement_approval"  # Replace with actual approval code

        form_data = [
            {"name": "amount", "value": str(amount)},
            {"name": "expense_type", "value": expense_type},
            {"name": "description", "value": description}
        ]

        return await self.create_approval_instance(
            approval_code=approval_code,
            form_data=form_data,
            user_id=user_id
        )


# Global approval service instance
approval_service = ApprovalService()
