"""
Calendar Service - Handles Feishu calendar operations
"""
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from app.core.client import feishu_client
from app.services.token_service import token_service


class CalendarService:
    """Service for handling Feishu calendar operations"""

    async def create_event(
        self,
        calendar_id: str,
        title: str,
        start_time: str,
        end_time: str,
        description: str = "",
        attendees: List[str] = None,
        location: str = ""
    ) -> Dict[str, Any]:
        """
        Create a calendar event

        Args:
            calendar_id: Calendar ID (use "primary" for user's primary calendar)
            title: Event title
            start_time: Start time in ISO 8601 format (e.g., "2024-01-01T09:00:00+08:00")
            end_time: End time in ISO 8601 format
            description: Event description
            attendees: List of attendee open_ids
            location: Event location

        Returns:
            API response with event details
        """
        token = await token_service.get_tenant_access_token()

        event_data = {
            "event": {
                "summary": title,
                "description": description,
                "location": {"name": location},
                "start": {"time_zone": "Asia/Shanghai", "timestamp": self._datetime_to_timestamp(start_time)},
                "end": {"time_zone": "Asia/Shanghai", "timestamp": self._datetime_to_timestamp(end_time)},
            }
        }

        if attendees:
            event_data["event"]["attendees"] = [
                {"open_id": attendee} for attendee in attendees
            ]

        return await feishu_client.create_calendar_event(
            calendar_id=calendar_id,
            event_data=event_data,
            tenant_access_token=token
        )

    async def get_events(
        self,
        calendar_id: str,
        start_time: str,
        end_time: str
    ) -> Dict[str, Any]:
        """
        Get calendar events within a time range

        Args:
            calendar_id: Calendar ID (use "primary" for user's primary calendar)
            start_time: Start time in ISO 8601 format
            end_time: End time in ISO 8601 format

        Returns:
            List of events
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.get_calendar_events(
            calendar_id=calendar_id,
            start_time=self._datetime_to_timestamp(start_time),
            end_time=self._datetime_to_timestamp(end_time),
            tenant_access_token=token
        )

    async def update_event(
        self,
        calendar_id: str,
        event_id: str,
        title: str = None,
        start_time: str = None,
        end_time: str = None,
        description: str = None,
        location: str = None
    ) -> Dict[str, Any]:
        """
        Update a calendar event

        Args:
            calendar_id: Calendar ID
            event_id: Event ID
            title: New title (optional)
            start_time: New start time (optional)
            end_time: New end time (optional)
            description: New description (optional)
            location: New location (optional)

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        event_data = {"event": {}}

        if title:
            event_data["event"]["summary"] = title
        if description:
            event_data["event"]["description"] = description
        if location:
            event_data["event"]["location"] = {"name": location}
        if start_time:
            event_data["event"]["start"] = {
                "time_zone": "Asia/Shanghai",
                "timestamp": self._datetime_to_timestamp(start_time)
            }
        if end_time:
            event_data["event"]["end"] = {
                "time_zone": "Asia/Shanghai",
                "timestamp": self._datetime_to_timestamp(end_time)
            }

        return await feishu_client.update_calendar_event(
            calendar_id=calendar_id,
            event_id=event_id,
            event_data=event_data,
            tenant_access_token=token
        )

    async def delete_event(
        self,
        calendar_id: str,
        event_id: str
    ) -> Dict[str, Any]:
        """
        Delete a calendar event

        Args:
            calendar_id: Calendar ID
            event_id: Event ID

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.delete_calendar_event(
            calendar_id=calendar_id,
            event_id=event_id,
            tenant_access_token=token
        )

    @staticmethod
    def _datetime_to_timestamp(dt_str: str) -> str:
        """
        Convert ISO 8601 datetime to Feishu timestamp format

        Args:
            dt_str: ISO 8601 datetime string

        Returns:
            Timestamp string (e.g., "1704067200")
        """
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        return str(int(dt.timestamp()))


# Global calendar service instance
calendar_service = CalendarService()
