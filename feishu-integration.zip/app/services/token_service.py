"""
Token Service - Manages Feishu access tokens with caching
"""
import time
from typing import Optional, Dict
from app.core.client import feishu_client
from app.core.config import settings


class TokenService:
    """Service for managing Feishu access tokens"""

    def __init__(self):
        self._token_cache: Dict[str, Dict] = {}
        self._redis_client = None

    async def get_tenant_access_token(self, force_refresh: bool = False) -> str:
        """
        Get tenant access token with caching

        Args:
            force_refresh: Force refresh the token even if cached

        Returns:
            Valid tenant access token
        """
        cache_key = "tenant_access_token"

        # Check cache first (in-memory)
        if not force_refresh and cache_key in self._token_cache:
            token_data = self._token_cache[cache_key]
            if token_data["expires_at"] > time.time() + 300:  # 5 min buffer
                return token_data["token"]

        # Get fresh token from Feishu
        token = await feishu_client.get_tenant_access_token()

        # Cache the token (default 2 hours expiry)
        self._token_cache[cache_key] = {
            "token": token,
            "expires_at": time.time() + settings.token_cache_ttl
        }

        return token

    async def get_app_access_token(self, force_refresh: bool = False) -> str:
        """
        Get app access token with caching

        Args:
            force_refresh: Force refresh the token even if cached

        Returns:
            Valid app access token
        """
        cache_key = "app_access_token"

        # Check cache first (in-memory)
        if not force_refresh and cache_key in self._token_cache:
            token_data = self._token_cache[cache_key]
            if token_data["expires_at"] > time.time() + 300:  # 5 min buffer
                return token_data["token"]

        # Get fresh token from Feishu
        token = await feishu_client.get_app_access_token()

        # Cache the token (default 2 hours expiry)
        self._token_cache[cache_key] = {
            "token": token,
            "expires_at": time.time() + settings.token_cache_ttl
        }

        return token

    def clear_cache(self):
        """Clear all cached tokens"""
        self._token_cache.clear()


# Global token service instance
token_service = TokenService()
