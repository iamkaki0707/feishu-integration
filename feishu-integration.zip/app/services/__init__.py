"""
Services module for Feishu integration
"""
from app.services.token_service import token_service, TokenService
from app.services.message_service import message_service, MessageService
from app.services.calendar_service import calendar_service, CalendarService
from app.services.approval_service import approval_service, ApprovalService

__all__ = [
    "token_service",
    "TokenService",
    "message_service",
    "MessageService",
    "calendar_service",
    "CalendarService",
    "approval_service",
    "ApprovalService",
]
