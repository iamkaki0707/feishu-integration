"""
Message Service - Handles sending and processing messages
"""
import json
from typing import Dict, Any, Optional, List
from app.core.client import feishu_client
from app.services.token_service import token_service


class MessageService:
    """Service for handling Feishu messages"""

    async def send_text_message(
        self,
        receive_id: str,
        text: str,
        receive_id_type: str = "open_id"
    ) -> Dict[str, Any]:
        """
        Send a text message

        Args:
            receive_id: Receiver's ID (user_id, open_id, union_id, or chat_id)
            text: Text content to send
            receive_id_type: Type of receiver ID

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        content = json.dumps({"text": text})

        return await feishu_client.send_message(
            receive_id_type=receive_id_type,
            receive_id=receive_id,
            msg_type="text",
            content=content,
            tenant_access_token=token
        )

    async def send_rich_text_message(
        self,
        receive_id: str,
        rich_text: Dict[str, Any],
        receive_id_type: str = "open_id"
    ) -> Dict[str, Any]:
        """
        Send a rich text message

        Args:
            receive_id: Receiver's ID
            rich_text: Rich text content (JSON structure)
            receive_id_type: Type of receiver ID

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        content = json.dumps(rich_text)

        return await feishu_client.send_message(
            receive_id_type=receive_id_type,
            receive_id=receive_id,
            msg_type="rich_text",
            content=content,
            tenant_access_token=token
        )

    async def send_interactive_card(
        self,
        receive_id: str,
        card_template: Dict[str, Any],
        receive_id_type: str = "open_id"
    ) -> Dict[str, Any]:
        """
        Send an interactive card message

        Args:
            receive_id: Receiver's ID
            card_template: Card template JSON
            receive_id_type: Type of receiver ID

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        content = json.dumps(card_template)

        return await feishu_client.send_message(
            receive_id_type=receive_id_type,
            receive_id=receive_id,
            msg_type="interactive",
            content=content,
            tenant_access_token=token
        )

    async def send_message_to_chat(
        self,
        chat_id: str,
        msg_type: str,
        content: str
    ) -> Dict[str, Any]:
        """
        Send message to a chat/group

        Args:
            chat_id: Chat ID
            msg_type: Message type (text, rich_text, interactive)
            content: Message content

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.send_message(
            receive_id_type="chat_id",
            receive_id=chat_id,
            msg_type=msg_type,
            content=content,
            tenant_access_token=token
        )

    async def reply_to_message(
        self,
        message_id: str,
        msg_type: str,
        content: str
    ) -> Dict[str, Any]:
        """
        Reply to an existing message

        Args:
            message_id: Message ID to reply to
            msg_type: Message type
            content: Message content

        Returns:
            API response
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.reply_message(
            message_id=message_id,
            msg_type=msg_type,
            content=content,
            tenant_access_token=token
        )

    async def get_user_info(self, user_id: str, user_id_type: str = "open_id") -> Dict[str, Any]:
        """
        Get user information

        Args:
            user_id: User ID
            user_id_type: Type of user ID

        Returns:
            User information
        """
        token = await token_service.get_tenant_access_token()

        return await feishu_client.get_user_info(
            user_id=user_id,
            user_id_type=user_id_type,
            tenant_access_token=token
        )

    async def get_user_by_email(self, email: str) -> Optional[str]:
        """
        Get user open_id by email

        Args:
            email: User email

        Returns:
            User open_id or None
        """
        token = await token_service.get_tenant_access_token()

        result = await feishu_client.get_user_id_by_email(
            email=email,
            tenant_access_token=token
        )

        if result.get("code") == 0:
            user_list = result.get("data", {}).get("user_list", [])
            if user_list:
                return user_list[0].get("open_id")

        return None


# Global message service instance
message_service = MessageService()
