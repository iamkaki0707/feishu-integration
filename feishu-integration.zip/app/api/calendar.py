"""
Calendar API - REST endpoints for calendar operations
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from app.services.calendar_service import calendar_service

router = APIRouter(prefix="/calendar", tags=["calendar"])


class CreateEventRequest(BaseModel):
    """Request model for creating calendar event"""
    calendar_id: str = "primary"
    title: str
    start_time: str  # ISO 8601 format
    end_time: str    # ISO 8601 format
    description: str = ""
    attendees: List[str] = []
    location: str = ""


class UpdateEventRequest(BaseModel):
    """Request model for updating calendar event"""
    calendar_id: str = "primary"
    event_id: str
    title: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    description: Optional[str] = None
    location: Optional[str] = None


class DeleteEventRequest(BaseModel):
    """Request model for deleting calendar event"""
    calendar_id: str = "primary"
    event_id: str


class GetEventsRequest(BaseModel):
    """Request model for getting calendar events"""
    calendar_id: str = "primary"
    start_time: str  # ISO 8601 format
    end_time: str    # ISO 8601 format


@router.post("/events")
async def create_event(request: CreateEventRequest) -> Dict[str, Any]:
    """
    Create a new calendar event
    """
    result = await calendar_service.create_event(
        calendar_id=request.calendar_id,
        title=request.title,
        start_time=request.start_time,
        end_time=request.end_time,
        description=request.description,
        attendees=request.attendees,
        location=request.location
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to create event: {result.get('msg')}"
        )

    return result


@router.get("/events")
async def get_events(
    calendar_id: str = "primary",
    start_time: str = None,
    end_time: str = None
) -> Dict[str, Any]:
    """
    Get calendar events within a time range

    Query parameters:
    - calendar_id: Calendar ID (default: "primary")
    - start_time: Start time in ISO 8601 format
    - end_time: End time in ISO 8601 format
    """
    if not start_time or not end_time:
        raise HTTPException(
            status_code=400,
            detail="start_time and end_time are required"
        )

    result = await calendar_service.get_events(
        calendar_id=calendar_id,
        start_time=start_time,
        end_time=end_time
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to get events: {result.get('msg')}"
        )

    return result


@router.put("/events/{event_id}")
async def update_event(
    event_id: str,
    request: UpdateEventRequest
) -> Dict[str, Any]:
    """
    Update an existing calendar event
    """
    result = await calendar_service.update_event(
        calendar_id=request.calendar_id,
        event_id=event_id,
        title=request.title,
        start_time=request.start_time,
        end_time=request.end_time,
        description=request.description,
        location=request.location
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to update event: {result.get('msg')}"
        )

    return result


@router.delete("/events/{event_id}")
async def delete_event(
    event_id: str,
    calendar_id: str = "primary"
) -> Dict[str, Any]:
    """
    Delete a calendar event
    """
    result = await calendar_service.delete_event(
        calendar_id=calendar_id,
        event_id=event_id
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to delete event: {result.get('msg')}"
        )

    return result
