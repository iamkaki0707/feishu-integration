"""
Webhook API - Handles incoming events from Feishu
"""
import json
from fastapi import APIRouter, Request, Header, HTTPException
from typing import Optional, Dict, Any
from app.core.config import settings
from app.core.security import security_tool
from app.services.message_service import message_service

router = APIRouter(prefix="/webhook", tags=["webhook"])


@router.get("/")
async def verify_webhook(
    challenge: Optional[str] = None,
    signature: Optional[str] = Header(None),
    timestamp: Optional[str] = Header(None),
    nonce: Optional[str] = Header(None)
):
    """
    Verify webhook URL (GET request from Feishu for URL verification)
    """
    if challenge:
        return {"challenge": challenge}

    return {"status": "ok"}


@router.post("/")
async def receive_webhook_event(
    request: Request,
    signature: Optional[str] = Header(None),
    timestamp: Optional[str] = Header(None),
    nonce: Optional[str] = Header(None)
):
    """
    Receive webhook events from Feishu
    """
    # Get raw body for signature verification
    body = await request.body()
    body_str = body.decode('utf-8')

    # Verify signature if encrypt_key is configured
    if settings.feishu_encrypt_key:
        if not signature or not timestamp or not nonce:
            raise HTTPException(status_code=401, detail="Missing headers for verification")

        if not security_tool.verify_signature(
            signature=signature,
            timestamp=timestamp,
            nonce=nonce,
            body=body_str,
            encrypt_key=settings.feishu_encrypt_key
        ):
            raise HTTPException(status_code=403, detail="Invalid signature")

    # Parse the event body
    try:
        event_data = json.loads(body_str)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    # Handle URL verification challenge
    if event_data.get("type") == "url_verification":
        return {"challenge": event_data.get("challenge")}

    # Get event type
    event_type = event_data.get("header", {}).get("event_type")

    # Process different event types
    if event_type == "im.message.receive_v1":
        # Handle incoming message
        return await handle_incoming_message(event_data)

    elif event_type == "calendar.event.change_v1":
        # Handle calendar event changes
        return await handle_calendar_event(event_data)

    elif event_type == "approval.instance.status_changed_v1":
        # Handle approval status changes
        return await handle_approval_status_change(event_data)

    else:
        print(f"Received event type: {event_type}")
        print(f"Event data: {event_data}")

    return {"status": "ok"}


async def handle_incoming_message(event_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle incoming message events
    """
    try:
        # Extract message details
        message = event_data.get("event", {})
        message_id = message.get("message", {}).get("message_id")
        msg_type = message.get("message", {}).get("msg_type")
        sender_id = message.get("sender", {}).get("sender_id", {}).get("open_id")
        chat_id = message.get("message", {}).get("chat_id")

        # Get message content
        content = message.get("message", {}).get("content", "")

        print(f"Received message from {sender_id}: {msg_type}")
        print(f"Message content: {content}")

        # Process message based on type
        if msg_type == "text":
            # Parse text content
            try:
                text_content = json.loads(content).get("text", "")
            except:
                text_content = content

            # Bot response logic - echo back or custom response
            if text_content:
                # Simple echo response
                response_text = f"收到消息: {text_content}"

                # Send reply
                await message_service.reply_to_message(
                    message_id=message_id,
                    msg_type="text",
                    content=json.dumps({"text": response_text})
                )

        elif msg_type == "interactive":
            # Handle interactive card actions
            try:
                card_content = json.loads(content)
                # Process card action...
            except:
                pass

        return {"status": "message_processed"}

    except Exception as e:
        print(f"Error handling message: {e}")
        return {"status": "error", "message": str(e)}


async def handle_calendar_event(event_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle calendar event change events
    """
    try:
        calendar_event = event_data.get("event", {})
        event_type = calendar_event.get("event_type")
        calendar_id = calendar_event.get("calendar_id")
        event_id = calendar_event.get("event_id")

        print(f"Calendar event: {event_type} - {calendar_id}/{event_id}")

        return {"status": "calendar_event_processed"}

    except Exception as e:
        print(f"Error handling calendar event: {e}")
        return {"status": "error", "message": str(e)}


async def handle_approval_status_change(event_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle approval status change events
    """
    try:
        approval_event = event_data.get("event", {})
        instance_id = approval_event.get("instance_id")
        status = approval_event.get("status")

        print(f"Approval instance {instance_id} status changed to: {status}")

        # TODO: Update local database with approval status

        return {"status": "approval_event_processed"}

    except Exception as e:
        print(f"Error handling approval event: {e}")
        return {"status": "error", "message": str(e)}
