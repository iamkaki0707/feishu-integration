"""
Approval API - REST endpoints for approval operations
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from app.services.approval_service import approval_service

router = APIRouter(prefix="/approval", tags=["approval"])


class CreateApprovalRequest(BaseModel):
    """Request model for creating approval instance"""
    approval_code: str
    form_data: List[Dict[str, Any]]
    user_id: Optional[str] = None
    user_id_type: str = "open_id"


class ApproveRequest(BaseModel):
    """Request model for approving an instance"""
    instance_id: str
    comment: str = ""


class RejectRequest(BaseModel):
    """Request model for rejecting an instance"""
    instance_id: str
    comment: str = ""


class LeaveApprovalRequest(BaseModel):
    """Request model for creating leave approval"""
    user_id: str
    leave_type: str
    start_date: str
    end_date: str
    reason: str = ""


class ReimbursementApprovalRequest(BaseModel):
    """Request model for creating reimbursement approval"""
    user_id: str
    amount: float
    expense_type: str
    description: str


@router.post("/instances")
async def create_approval_instance(request: CreateApprovalRequest) -> Dict[str, Any]:
    """
    Create a new approval instance

    Args:
        approval_code: Approval definition code (from Feishu admin console)
        form_data: Form data as list of {name: field_name, value: field_value}
    """
    result = await approval_service.create_approval_instance(
        approval_code=request.approval_code,
        form_data=request.form_data,
        user_id=request.user_id,
        user_id_type=request.user_id_type
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to create approval: {result.get('msg')}"
        )

    return result


@router.get("/instances/{instance_id}")
async def get_approval_instance_status(instance_id: str) -> Dict[str, Any]:
    """
    Get approval instance status

    Args:
        instance_id: Approval instance ID
    """
    result = await approval_service.get_approval_instance_status(
        instance_id=instance_id
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to get instance status: {result.get('msg')}"
        )

    return result


@router.get("/definitions")
async def get_approval_definitions() -> Dict[str, Any]:
    """
    Get list of approval definitions
    """
    result = await approval_service.get_approval_definitions()

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to get definitions: {result.get('msg')}"
        )

    return result


@router.post("/instances/{instance_id}/approve")
async def approve_instance(
    instance_id: str,
    request: ApproveRequest
) -> Dict[str, Any]:
    """
    Approve an approval instance

    Args:
        instance_id: Approval instance ID
        comment: Optional approval comment
    """
    result = await approval_service.approve_request(
        instance_id=instance_id,
        comment=request.comment
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to approve: {result.get('msg')}"
        )

    return result


@router.post("/instances/{instance_id}/reject")
async def reject_instance(
    instance_id: str,
    request: RejectRequest
) -> Dict[str, Any]:
    """
    Reject an approval instance

    Args:
        instance_id: Approval instance ID
        comment: Optional rejection comment
    """
    result = await approval_service.reject_request(
        instance_id=instance_id,
        comment=request.comment
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to reject: {result.get('msg')}"
        )

    return result


# Helper endpoints for common approval types

@router.post("/leave")
async def create_leave_approval(request: LeaveApprovalRequest) -> Dict[str, Any]:
    """
    Create a leave approval request (helper endpoint)
    """
    result = await approval_service.create_leave_approval(
        user_id=request.user_id,
        leave_type=request.leave_type,
        start_date=request.start_date,
        end_date=request.end_date,
        reason=request.reason
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to create leave approval: {result.get('msg')}"
        )

    return result


@router.post("/reimbursement")
async def create_reimbursement_approval(request: ReimbursementApprovalRequest) -> Dict[str, Any]:
    """
    Create a reimbursement approval request (helper endpoint)
    """
    result = await approval_service.create_reimbursement_approval(
        user_id=request.user_id,
        amount=request.amount,
        expense_type=request.expense_type,
        description=request.description
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to create reimbursement: {result.get('msg')}"
        )

    return result
