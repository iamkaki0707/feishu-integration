"""
Messages API - REST endpoints for sending messages
"""
import json
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from app.services.message_service import message_service

router = APIRouter(prefix="/messages", tags=["messages"])


class SendTextMessageRequest(BaseModel):
    """Request model for sending text message"""
    receive_id: str
    text: str
    receive_id_type: str = "open_id"


class SendRichTextMessageRequest(BaseModel):
    """Request model for sending rich text message"""
    receive_id: str
    rich_text: Dict[str, Any]
    receive_id_type: str = "open_id"


class SendCardMessageRequest(BaseModel):
    """Request model for sending interactive card"""
    receive_id: str
    card_template: Dict[str, Any]
    receive_id_type: str = "open_id"


class SendToChatRequest(BaseModel):
    """Request model for sending message to chat"""
    chat_id: str
    msg_type: str
    content: str


class ReplyMessageRequest(BaseModel):
    """Request model for replying to message"""
    message_id: str
    msg_type: str
    content: str


class GetUserInfoRequest(BaseModel):
    """Request model for getting user info"""
    user_id: str
    user_id_type: str = "open_id"


@router.post("/text")
async def send_text_message(request: SendTextMessageRequest) -> Dict[str, Any]:
    """
    Send a text message to a user
    """
    result = await message_service.send_text_message(
        receive_id=request.receive_id,
        text=request.text,
        receive_id_type=request.receive_id_type
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to send message: {result.get('msg')}"
        )

    return result


@router.post("/rich_text")
async def send_rich_text_message(request: SendRichTextMessageRequest) -> Dict[str, Any]:
    """
    Send a rich text message to a user
    """
    result = await message_service.send_rich_text_message(
        receive_id=request.receive_id,
        rich_text=request.rich_text,
        receive_id_type=request.receive_id_type
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to send message: {result.get('msg')}"
        )

    return result


@router.post("/card")
async def send_interactive_card(request: SendCardMessageRequest) -> Dict[str, Any]:
    """
    Send an interactive card message to a user
    """
    result = await message_service.send_interactive_card(
        receive_id=request.receive_id,
        card_template=request.card_template,
        receive_id_type=request.receive_id_type
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to send card: {result.get('msg')}"
        )

    return result


@router.post("/chat")
async def send_message_to_chat(request: SendToChatRequest) -> Dict[str, Any]:
    """
    Send a message to a chat/group
    """
    result = await message_service.send_message_to_chat(
        chat_id=request.chat_id,
        msg_type=request.msg_type,
        content=request.content
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to send message: {result.get('msg')}"
        )

    return result


@router.post("/reply")
async def reply_to_message(request: ReplyMessageRequest) -> Dict[str, Any]:
    """
    Reply to an existing message
    """
    result = await message_service.reply_to_message(
        message_id=request.message_id,
        msg_type=request.msg_type,
        content=request.content
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to reply: {result.get('msg')}"
        )

    return result


@router.get("/user/{user_id}")
async def get_user_info(user_id: str, user_id_type: str = "open_id") -> Dict[str, Any]:
    """
    Get user information
    """
    result = await message_service.get_user_info(
        user_id=user_id,
        user_id_type=user_id_type
    )

    if result.get("code") != 0:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to get user info: {result.get('msg')}"
        )

    return result


@router.get("/user/email/{email}")
async def get_user_by_email(email: str) -> Dict[str, Any]:
    """
    Get user open_id by email
    """
    user_id = await message_service.get_user_by_email(email=email)

    if user_id:
        return {"open_id": user_id}
    else:
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )
