"""
Feishu Webhook Security - Signature Verification and AES Decryption
"""
import hmac
import hashlib
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from typing import Dict, Any, Optional
from app.core.config import settings


class SecurityTool:
    """Security tools for Feishu webhook verification"""

    @staticmethod
    def verify_signature(
        signature: str,
        timestamp: str,
        nonce: str,
        body: str,
        encrypt_key: Optional[str] = None
    ) -> bool:
        """
        Verify Feishu webhook signature

        Args:
            signature: X-Lark-Signature header value
            timestamp: X-Lark-Timestamp header value
            nonce: X-Lark-Nonce header value
            body: Raw request body
            encrypt_key: App encrypt key (from Feishu developer console)

        Returns:
            True if signature is valid
        """
        # If encrypt_key is provided, body is encrypted
        # Need to decrypt first
        if encrypt_key:
            decrypted_body = SecurityTool.decrypt(body, encrypt_key)
            if decrypted_body is None:
                return False
            body = decrypted_body

        # Build signature string
        sign_string = f"{timestamp}{nonce}{body}"

        # Calculate signature using HMAC-SHA256
        app_secret = settings.feishu_app_secret.encode('utf-8')
        sign_string_bytes = sign_string.encode('utf-8')

        hashed = hmac.new(app_secret, sign_string_bytes, hashlib.sha256)
        calculated_signature = base64.b64encode(hashed.digest()).decode('utf-8')

        return hmac.compare_digest(signature, calculated_signature)

    @staticmethod
    def decrypt(encrypt_str: str, encrypt_key: str) -> Optional[str]:
        """
        Decrypt encrypted webhook body

        Args:
            encrypt_str: Encrypted string from webhook
            encrypt_key: App encrypt key

        Returns:
            Decrypted JSON string or None if decryption fails
        """
        try:
            # Decode the encrypted string from base64
            encrypted_bytes = base64.b64decode(encrypt_str)

            # Decode the encryption key from base64
            key_bytes = base64.b64decode(encrypt_key)

            # Create AES cipher
            cipher = AES.new(key_bytes, AES.MODE_CBC, key_bytes[:16])

            # Decrypt and unpad
            decrypted = cipher.decrypt(encrypted_bytes)
            decrypted_text = unpad(decrypted, AES.block_size)

            # Return as string
            return decrypted_text.decode('utf-8')
        except Exception as e:
            print(f"Decryption error: {e}")
            return None

    @staticmethod
    def encrypt(message: str, encrypt_key: str) -> Optional[str]:
        """
        Encrypt message for sending to Feishu

        Args:
            message: Message to encrypt
            encrypt_key: App encrypt key

        Returns:
            Encrypted string or None if encryption fails
        """
        try:
            # Pad the message
            padded_message = message.encode('utf-8')
            # Use PKCS7 padding
            block_size = AES.block_size
            padding_length = block_size - (len(padded_message) % block_size)
            padded_message += bytes([padding_length] * padding_length)

            # Decode the encryption key from base64
            key_bytes = base64.b64decode(encrypt_key)

            # Create AES cipher
            cipher = AES.new(key_bytes, AES.MODE_CBC, key_bytes[:16])

            # Encrypt
            encrypted = cipher.encrypt(padded_message)

            # Encode to base64
            return base64.b64encode(encrypted).decode('utf-8')
        except Exception as e:
            print(f"Encryption error: {e}")
            return None


# Global security tool instance
security_tool = SecurityTool()
