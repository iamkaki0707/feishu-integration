"""
Feishu API HTTP Client
"""
import httpx
from typing import Dict, Any, Optional
from app.core.config import settings


class FeishuClient:
    """HTTP Client for Feishu Open API"""

    def __init__(self):
        self.base_url = settings.feishu_api_base_url
        self.app_id = settings.feishu_app_id
        self.app_secret = settings.feishu_app_secret

    async def get_tenant_access_token(self) -> str:
        """
        Get tenant access token (企业自建应用)
        Token有效期为2小时，需缓存
        """
        url = f"{self.base_url}/auth/v3/tenant_access_token/internal"

        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload)
            data = response.json()

            if data.get("code") == 0:
                return data.get("tenant_access_token")
            else:
                raise Exception(f"Failed to get tenant access token: {data}")

    async def get_app_access_token(self) -> str:
        """
        Get app access token (适用于应用身份的 API 调用)
        """
        url = f"{self.base_url}/auth/v3/app_access_token/internal"

        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload)
            data = response.json()

            if data.get("code") == 0:
                return data.get("app_access_token")
            else:
                raise Exception(f"Failed to get app access token: {data}")

    async def send_message(
        self,
        receive_id_type: str,
        receive_id: str,
        msg_type: str,
        content: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Send message to user or group

        Args:
            receive_id_type: "user_id" or "open_id" or "union_id" or "chat_id"
            receive_id: The receiver's ID
            msg_type: "text", "rich_text", "image", "interactive"
            content: Message content (JSON string for rich types)
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/im/v1/messages"
        params = {
            "receive_id_type": receive_id_type
        }

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {
            "receive_id": receive_id,
            "msg_type": msg_type,
            "content": content
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                params=params,
                json=payload,
                headers=headers
            )
            return response.json()

    async def reply_message(
        self,
        message_id: str,
        msg_type: str,
        content: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Reply to a message

        Args:
            message_id: The message ID to reply to
            msg_type: "text", "rich_text", "image", "interactive"
            content: Message content
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/im/v1/messages/{message_id}/reply"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {
            "msg_type": msg_type,
            "content": content
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )
            return response.json()

    async def upload_image(
        self,
        image_type: str,
        image_path: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Upload image to Feishu

        Args:
            image_type: "message" or "avatar"
            image_path: Local path to image file
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/im/v1/images"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        with open(image_path, "rb") as f:
            files = {
                "image": (image_path.split("/")[-1], f, "image/jpeg")
            }
            data = {
                "image_type": image_type
            }

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    files=files,
                    data=data,
                    headers=headers
                )
                return response.json()

    async def get_user_info(
        self,
        user_id: str,
        user_id_type: str = "open_id",
        tenant_access_token: str = ""
    ) -> Dict[str, Any]:
        """
        Get user information

        Args:
            user_id: User ID
            user_id_type: "user_id", "open_id", "union_id"
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/contact/v3/users/{user_id}"
        params = {
            "user_id_type": user_id_type
        }

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                params=params,
                headers=headers
            )
            return response.json()

    async def get_user_id_by_email(
        self,
        email: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Get user ID by email

        Args:
            email: User email
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/contact/v3/users/batch_get_id"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {
            "emails": [email]
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )
            return response.json()

    async def create_calendar_event(
        self,
        calendar_id: str,
        event_data: Dict[str, Any],
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Create calendar event

        Args:
            calendar_id: Calendar ID (primary for user's primary calendar)
            event_data: Event details
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=event_data,
                headers=headers
            )
            return response.json()

    async def get_calendar_events(
        self,
        calendar_id: str,
        start_time: str,
        end_time: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Get calendar events

        Args:
            calendar_id: Calendar ID
            start_time: Start time (ISO 8601 format)
            end_time: End time (ISO 8601 format)
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events"

        params = {
            "start_time": start_time,
            "end_time": end_time
        }

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                params=params,
                headers=headers
            )
            return response.json()

    async def update_calendar_event(
        self,
        calendar_id: str,
        event_id: str,
        event_data: Dict[str, Any],
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Update calendar event

        Args:
            calendar_id: Calendar ID
            event_id: Event ID
            event_data: Updated event details
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.put(
                url,
                json=event_data,
                headers=headers
            )
            return response.json()

    async def delete_calendar_event(
        self,
        calendar_id: str,
        event_id: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Delete calendar event

        Args:
            calendar_id: Calendar ID
            event_id: Event ID
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.delete(
                url,
                headers=headers
            )
            return response.json()

    async def create_approval_instance(
        self,
        approval_code: str,
        form_data: Dict[str, Any],
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Create approval instance (审批实例)

        Args:
            approval_code: Approval definition code
            form_data: Form data for approval
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/approval/v4/instances"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {
            "approval_code": approval_code,
            "form": form_data
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )
            return response.json()

    async def get_approval_instance(
        self,
        instance_id: str,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Get approval instance status

        Args:
            instance_id: Approval instance ID
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/approval/v4/instances/{instance_id}"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers=headers
            )
            return response.json()

    async def get_approval_definitions(
        self,
        tenant_access_token: str
    ) -> Dict[str, Any]:
        """
        Get approval definitions

        Args:
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/approval/v4/definitions"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        async with httpx.AsyncClient() as client:
            response = await client.get(
                url,
                headers=headers
            )
            return response.json()

    async def approve_instance(
        self,
        instance_id: str,
        comment: Optional[str] = None,
        tenant_access_token: str = ""
    ) -> Dict[str, Any]:
        """
        Approve an approval instance

        Args:
            instance_id: Approval instance ID
            comment: Approval comment
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/approval/v4/instances/{instance_id}/approve"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {}
        if comment:
            payload["comment"] = comment

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )
            return response.json()

    async def reject_instance(
        self,
        instance_id: str,
        comment: Optional[str] = None,
        tenant_access_token: str = ""
    ) -> Dict[str, Any]:
        """
        Reject an approval instance

        Args:
            instance_id: Approval instance ID
            comment: Rejection comment
            tenant_access_token: Valid tenant access token
        """
        url = f"{self.base_url}/approval/v4/instances/{instance_id}/reject"

        headers = {
            "Authorization": f"Bearer {tenant_access_token}"
        }

        payload = {}
        if comment:
            payload["comment"] = comment

        async with httpx.AsyncClient() as client:
            response = await client.post(
                url,
                json=payload,
                headers=headers
            )
            return response.json()


# Global client instance
feishu_client = FeishuClient()
