"""
Feishu Integration Application Configuration
"""
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application configuration settings"""

    # Feishu Application Credentials
    feishu_app_id: str = ""
    feishu_app_secret: str = ""
    feishu_encrypt_key: Optional[str] = ""

    # Feishu API Configuration
    feishu_api_base_url: str = "https://open.feishu.cn/open-apis"

    # Server Configuration
    host: str = "0.0.0.0"
    port: int = 8000

    # Redis Configuration (for token caching)
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: Optional[str] = None
    redis_db: int = 0

    # Token cache TTL (in seconds) - Feishu tokens expire in 2 hours
    token_cache_ttl: int = 7200

    class Config:
        env_file = ".env"
        extra = "allow"


settings = Settings()
