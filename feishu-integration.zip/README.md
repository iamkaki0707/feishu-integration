# Feishu Integration Gateway

Enterprise integration gateway for Feishu (飞书) - Messages, Calendar, and Approvals

## Features

- **Message Management**: Send and receive text, rich text, and interactive card messages
- **Calendar Integration**: Create, read, update, and delete calendar events
- **Approval Workflow**: Create and manage approval instances
- **Webhook Support**: Receive real-time events from Feishu

## Quick Start

### Prerequisites

- Python 3.8+
- Feishu Developer Account

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd feishu_integration

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your Feishu App credentials
```

### Run the Server

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /` | Service info |
| `GET /health` | Health check |
| `POST /api/v1/webhook` | Feishu webhook endpoint |
| `POST /api/v1/messages/text` | Send text message |
| `POST /api/v1/messages/card` | Send interactive card |
| `POST /api/v1/calendar/events` | Create calendar event |
| `POST /api/v1/approval/instances` | Create approval instance |

## Feishu Configuration

1. Create an app at [Feishu Open Platform](https://open.feishu.cn/)
2. Get App ID and App Secret
3. Enable required permissions:
   - im.message:send_as_bot
   - im.message:receive
   - calendar:* (for calendar features)
   - approval:* (for approval features)
4. Configure webhook URL in developer console

## License

MIT
